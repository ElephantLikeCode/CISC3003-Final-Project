create
    definer = root@localhost function sum_of_product_with_Thirt(The_value_of_product int) returns int deterministic
BEGIN
 DECLARE b int;
  Select 20 into b; 
  -- 20 is the price of Tshirt in our dataset
  RETURN The_value_of_product+b;
END;

