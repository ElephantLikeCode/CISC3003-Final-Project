create
    definer = root@localhost procedure get_product_nameandpriceviaID(IN id int)
BEGIN
    select name,price from product where Product_id = id;
END;

