create definer = root@localhost view product_price_bigger_than50 as
select `mydb`.`product`.`Product_id` AS `Product_id`, `mydb`.`product`.`name` AS `name`
from `mydb`.`product`
where (`mydb`.`product`.`price` > 50);

