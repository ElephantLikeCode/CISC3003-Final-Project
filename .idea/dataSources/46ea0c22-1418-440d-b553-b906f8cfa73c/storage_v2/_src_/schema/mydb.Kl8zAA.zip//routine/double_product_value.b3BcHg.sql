create
    definer = root@localhost function double_product_value(The_value_of_product int) returns int deterministic
BEGIN
 DECLARE b int;
  Select 2 into b; 
  -- 20 is the price of Tshirt in our dataset
  RETURN 2*The_value_of_product;
END;

